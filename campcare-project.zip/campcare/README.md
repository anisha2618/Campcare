# CampCare – Relief Camp Management Platform

Safe People • Better Support • Stronger Communities

A working React app for managing relief camps: residents, QR IDs, accommodation, supplies, medical cases, responder lookup and reports.

## Run it
1. Unzip the folder.
2. Double-click `index.html` (needs internet once to load React and the QR library).

Login: any username, password `camp123`. Pick Administrator, Medical Staff or Responder.

## Demo flow (3 minutes)
1. Login as Administrator.
2. Register a resident and show the Resident ID and QR code.
3. Accommodation: allocate the resident to a block and space.
4. Supplies: record a distribution and show the low-stock alert.
5. Switch role to Medical Staff and update a medical case.
6. Switch role to Responder and search the resident to see details.
7. Reports: download Excel and print or save as PDF.
8. Logout.

## Features
- Role-based dashboards and access control
- Resident CRUD, search, filters, pagination
- QR code generation with print and download
- Accommodation allocation with occupied-space checks
- Supplies with stock in/out and low-stock warnings
- Medical cases with priority, status, notes, resolve
- Reports (5 tabs), notifications, settings, dark mode
- Data saved in the browser (localStorage); easy to swap for a backend API

## Prototype limits
- Scan QR button picks a random resident (type an ID to search for real)
- Excel download is a CSV file
- No real backend yet

## Future work
Database and login API, camera QR scanning, SMS alerts to families, multi-camp support.

## Publish for judges
Upload `index.html` to Netlify Drop (app.netlify.com/drop) or GitHub Pages and share the link.
